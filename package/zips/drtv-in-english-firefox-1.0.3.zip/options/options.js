// src/shared/storage.ts
var PROVIDER_PRESETS = {
  anthropic: {
    label: "Anthropic",
    endpoint: "https://api.anthropic.com/v1/messages",
    model: "claude-haiku-4-5"
  },
  openai: {
    label: "OpenAI",
    endpoint: "https://api.openai.com/v1/responses",
    model: "gpt-5-mini"
  },
  gemini: {
    label: "Gemini",
    endpoint: "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
    model: "gemini-3.5-flash"
  },
  alx: {
    label: "ALX",
    endpoint: "https://inference.alexandra.dk/v1/chat/completions",
    model: "qwen3.5-397b"
  },
  "openai-compatible": {
    label: "OpenAI-compatible",
    endpoint: "",
    model: ""
  }
};
var DEFAULTS = {
  provider: "alx",
  endpoint: PROVIDER_PRESETS.alx.endpoint,
  apiKey: "",
  model: PROVIDER_PRESETS.alx.model,
  batchSize: 5,
  contextWindow: 6,
  maxParallel: 20
};
var KEY = "providerConfig";
async function loadProviderConfig() {
  const got = await chrome.storage.local.get(KEY);
  return { ...DEFAULTS, ...got[KEY] ?? {} };
}
async function saveProviderConfig(cfg) {
  await chrome.storage.local.set({ [KEY]: cfg });
}

// src/background/cache.ts
var DB_NAME = "drtv-en-translations";
var STORE = "translations";
var VERSION = 1;
function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: "key" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function getCacheStats() {
  const db = await openDb();
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).getAll();
      req.onsuccess = () => {
        const all = req.result ?? [];
        let bytes = 0;
        for (const e of all) bytes += e.cuesJson.length;
        resolve({ entries: all.length, bytes });
      };
      req.onerror = () => reject(req.error);
    });
  } finally {
    db.close();
  }
}
async function clearCache() {
  const db = await openDb();
  try {
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } finally {
    db.close();
  }
}

// src/options/options.ts
function $(id) {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing #${id}`);
  return el;
}
function $sel(id) {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing #${id}`);
  return el;
}
function populateProviders() {
  const sel = $sel("provider");
  const entries = Object.entries(PROVIDER_PRESETS).sort(([a, pa], [b, pb]) => {
    if (a === "openai-compatible") return 1;
    if (b === "openai-compatible") return -1;
    return pa.label.localeCompare(pb.label);
  });
  for (const [key, preset] of entries) {
    const opt = document.createElement("option");
    opt.value = key;
    opt.textContent = preset.label;
    sel.appendChild(opt);
  }
}
function applyPreset(next) {
  const preset = PROVIDER_PRESETS[next];
  $("endpoint").value = preset.endpoint;
  $("model").value = preset.model;
  $("apiKey").value = "";
}
async function ensureEndpointPermission(endpoint) {
  let origins;
  try {
    const url = new URL(endpoint);
    origins = [`${url.protocol}//${url.hostname}/*`];
  } catch {
    return true;
  }
  try {
    return await chrome.permissions.request({ origins });
  } catch {
    return false;
  }
}
function setApiKeyLabel(provider) {
  const label = document.querySelector('label[for="apiKey"]');
  if (!label) return;
  label.textContent = provider === "openai-compatible" ? "API key (enter any value if the server doesn't require one)" : "API key";
}
async function init() {
  populateProviders();
  const cfg = await loadProviderConfig();
  $sel("provider").value = cfg.provider;
  $("endpoint").value = cfg.endpoint || PROVIDER_PRESETS[cfg.provider].endpoint;
  $("model").value = cfg.model || PROVIDER_PRESETS[cfg.provider].model;
  $("apiKey").value = cfg.apiKey;
  setApiKeyLabel(cfg.provider);
  $sel("provider").addEventListener("change", () => {
    const provider = $sel("provider").value;
    applyPreset(provider);
    setApiKeyLabel(provider);
  });
  document.getElementById("save").addEventListener("click", async () => {
    const status = document.getElementById("status");
    status.classList.remove("error");
    const provider = $sel("provider").value;
    const endpoint = $("endpoint").value.trim();
    const model = $("model").value.trim();
    const apiKey = $("apiKey").value;
    if (!endpoint || !model || !apiKey) {
      status.classList.add("error");
      status.textContent = "Endpoint, model, and API key are all required.";
      return;
    }
    if (!await ensureEndpointPermission(endpoint)) {
      status.classList.add("error");
      status.textContent = "Can't translate without permission to reach that endpoint. Save again to retry.";
      return;
    }
    const prev = await loadProviderConfig();
    const next = {
      provider,
      endpoint,
      model,
      apiKey,
      batchSize: prev.batchSize,
      contextWindow: prev.contextWindow,
      maxParallel: prev.maxParallel
    };
    await saveProviderConfig(next);
    status.textContent = "Saved.";
    setTimeout(() => status.textContent = "", 2e3);
  });
}
async function refreshCacheStats() {
  const el = document.getElementById("cacheStats");
  try {
    const { entries, bytes } = await getCacheStats();
    if (entries === 0) {
      el.textContent = "Nothing cached yet.";
    } else {
      el.textContent = `${entries} episode${entries === 1 ? "" : "s"} cached (${formatBytes(bytes)}).`;
    }
  } catch (err) {
    el.textContent = `Cache unavailable: ${err instanceof Error ? err.message : String(err)}`;
  }
}
function formatBytes(n) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}
document.getElementById("clearCache")?.addEventListener("click", async () => {
  await clearCache();
  await refreshCacheStats();
});
void init().then(refreshCacheStats);
//# sourceMappingURL=options.js.map
