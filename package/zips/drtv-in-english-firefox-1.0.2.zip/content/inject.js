"use strict";
(() => {
  // src/content/inject.ts
  (() => {
    const VTT_RE = /\.vtt(\?|#|$)|\.webvtt(\?|#|$)|\/subtitles\/[^?#]*\.m3u8(\?|#|$)|\/master[^/]*\.m3u8(\?|#|$)/i;
    const post = (url) => {
      try {
        window.postMessage(
          { source: "drtv-en", type: "vtt-url", url },
          window.location.origin
        );
      } catch (_err) {
      }
    };
    const origFetch = window.fetch.bind(window);
    window.fetch = function(input, init) {
      try {
        const url = typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
        if (url && VTT_RE.test(url)) post(url);
      } catch (_err) {
      }
      return origFetch(input, init);
    };
    const origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      try {
        const s = typeof url === "string" ? url : url.toString();
        if (VTT_RE.test(s)) post(s);
      } catch (_err) {
      }
      return origOpen.apply(this, [
        method,
        url,
        ...rest
      ]);
    };
    console.log("[drtv-en/inject] page-world VTT sniffer installed");
  })();
})();
//# sourceMappingURL=inject.js.map
