"use strict";
(() => {
  // src/content/early.ts
  (() => {
    const TAG = "[drtv-en/early]";
    window.addEventListener("message", (e) => {
      if (e.source !== window) return;
      const data = e.data;
      if (!data || data.source !== "drtv-en") return;
      if (data.type === "vtt-url" && data.url) {
        chrome.runtime.sendMessage({ type: "vtt-url", url: data.url }).catch(() => {
        });
      }
    });
    console.log(TAG, "page-world bridge installed");
  })();
})();
//# sourceMappingURL=early.js.map
